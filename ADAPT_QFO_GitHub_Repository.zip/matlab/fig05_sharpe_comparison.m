%% fig05_sharpe_comparison.m
% Figure 6 in Manuscript: Grouped bar chart — Sharpe ratio comparison across 7 methods & 3 regimes
% Reconciled to exact empirical benchmark metrics matching Table 4, Table S3, and regime_performance.csv
clear; clc; close all;
rng(42);

methods = {'Classical MVO','Black-Litterman','HRP','Exact MIQP (Gurobi Ref)','Simulated Annealing','Standard QAOA','ADAPT-QFO (Ours)'};
regimes = {'Bull (2017--19, 23--24)','Bear (2020, 2022)','Recovery (2020--21)'};

% Sharpe ratios matching Table 4, Table S3, and regime_performance.csv
sharpe_mu = [
    % MVO   BL    HRP   MIQP  SA    QAOA  ADAPT-QFO
     1.18, 1.27, 1.28, 1.48, 1.21, 1.24, 1.47;   % Bull
     0.31, 0.34, 0.38, 0.42, 0.35, 0.32, 0.41;   % Bear
     1.32, 1.46, 1.40, 1.74, 1.35, 1.38, 1.73;   % Recovery
];

% Standard deviations (0.00 for deterministic benchmarks: MVO, BL, HRP, MIQP; non-zero for stochastic algorithms: SA, QAOA, ADAPT-QFO)
sharpe_std = [
    0.00, 0.00, 0.00, 0.00, 0.14, 0.16, 0.14;   % Bull
    0.00, 0.00, 0.00, 0.00, 0.15, 0.19, 0.16;   % Bear
    0.00, 0.00, 0.00, 0.00, 0.16, 0.18, 0.13;   % Recovery
];

fig = figure('Units','centimeters','Position',[1 1 20 11],'Color','w');
set(fig,'PaperUnits','centimeters','PaperSize',[20 11],'PaperPosition',[0 0 20 11]);

n_m = numel(methods); n_r = numel(regimes);
x = 1:n_r;
w = 0.105; offsets = linspace(-(n_m-1)/2*w, (n_m-1)/2*w, n_m);

colors_m = [
    0.20 0.45 0.80;   % Classical MVO (Blue)
    0.30 0.65 0.80;   % Black-Litterman (Cyan)
    0.20 0.70 0.45;   % HRP (Green)
    0.40 0.40 0.40;   % Exact MIQP (Dark Gray reference)
    0.75 0.50 0.20;   % Simulated Annealing (Amber)
    0.95 0.55 0.20;   % Standard QAOA (Orange)
    0.85 0.15 0.10;   % ADAPT-QFO (Crimson)
];

hold on; grid on; box on;
handles = gobjects(n_m,1);
for m = 1:n_m
    xpos = x + offsets(m);
    b = bar(xpos, sharpe_mu(:,m)', w, 'FaceColor', colors_m(m,:), ...
        'EdgeColor','k','LineWidth',0.6);
    handles(m) = b;
    if max(sharpe_std(:,m)) > 0
        errorbar(xpos, sharpe_mu(:,m)', sharpe_std(:,m)', 'k.', ...
            'LineWidth',1.0,'CapSize',2.5);
    end
end

% Significance markers (Diebold-Mariano p < 0.001 vs MVO, n.s. vs MIQP)
for r = 1:n_r
    ymax = sharpe_mu(r,7) + sharpe_std(r,7) + 0.06;
    text(r + offsets(7), ymax, '***', 'HorizontalAlignment','center', ...
        'FontSize',10,'Color',colors_m(7,:),'FontWeight','bold');
end

% Annotate outperformance percentage over MVO
text(1 + offsets(7) - 0.02, sharpe_mu(1,7) + 0.24, '+24.6\%', 'Interpreter','latex','FontSize',7.5,'Color',colors_m(7,:));
text(2 + offsets(7) - 0.02, sharpe_mu(2,7) + 0.24, '+32.3\%', 'Interpreter','latex','FontSize',7.5,'Color',colors_m(7,:));
text(3 + offsets(7) - 0.02, sharpe_mu(3,7) + 0.24, '+31.1\%', 'Interpreter','latex','FontSize',7.5,'Color',colors_m(7,:));

yline(0,'k-','LineWidth',0.8);
xlabel('Market Regime','Interpreter','latex','FontSize',11);
ylabel('Annualized Sharpe Ratio','Interpreter','latex','FontSize',11);
title('Sharpe Ratio Comparison Across 7 Portfolio Models (50 Stochastic Repetitions)', ...
    'Interpreter','latex','FontSize',12,'FontWeight','bold');
xticks(x); xticklabels(regimes);
set(gca,'FontSize',10,'TickLabelInterpreter','latex','LineWidth',0.8,'XTickLabelRotation',0);
ylim([-0.20 2.15]);
legend(handles, methods, 'Location','NorthWest','Interpreter','latex','FontSize',7.5, ...
    'NumColumns',2);

FIG_DIR = fullfile(fileparts(mfilename('fullpath')),'..','figures');
if ~exist(FIG_DIR,'dir'), mkdir(FIG_DIR); end
print(fig,fullfile(FIG_DIR,'fig_05_sharpe_comparison.png'),'-dpng','-r600');
print(fig,fullfile(FIG_DIR,'fig_05_sharpe_comparison.eps'),'-depsc','-r600');
try; print(fig,fullfile(FIG_DIR,'fig_05_sharpe_comparison.pdf'),'-dpdf');
catch; saveas(fig,fullfile(FIG_DIR,'fig_05_sharpe_comparison.pdf')); end
fprintf('Figure 6 (fig_05_sharpe_comparison) saved with all 7 models.\n');
