# fetch_market_data.ps1
# Download daily historical adjusted close prices for 30 S&P 500 constituents + SPY (2015-01-01 to 2024-12-31)

$ErrorActionPreference = "Stop"
$tickers = @(
    'AAPL', 'MSFT', 'NVDA', 'AMZN', 'GOOGL', 'META', 'BRK-B', 'JPM', 'V', 'UNH',
    'JNJ', 'LLY', 'PG', 'KO', 'COST', 'HD', 'TSLA', 'XOM', 'CVX', 'NEE',
    'SO', 'DUK', 'CAT', 'UNP', 'GE', 'LIN', 'SHW', 'AMT', 'PLD', 'CSCO', 'SPY'
)

$outDir = "D:\Quantum finance\paper_output\benchmarks\data"
if (!(Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir -Force }

$period1 = 1420070400 # 2015-01-01
$period2 = 1735689600 # 2024-12-31

$allData = @{}
$timestamps = $null

Write-Host "Fetching historical daily data for $($tickers.Count) tickers..."

foreach ($t in $tickers) {
    Write-Host -NoNewline "  Fetching $t... "
    $url = "https://query1.finance.yahoo.com/v8/finance/chart/${t}?period1=${period1}&period2=${period2}&interval=1d"
    $raw = & curl.exe -s -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" $url
    $json = $raw | ConvertFrom-Json
    
    if ($json.chart.result -and $json.chart.result[0].timestamp) {
        $ts = $json.chart.result[0].timestamp
        $adjClose = $json.chart.result[0].indicators.adjclose[0].adjclose
        if (!$adjClose) {
            $adjClose = $json.chart.result[0].indicators.quote[0].close
        }
        $count = $ts.Count
        Write-Host "OK ($count days)"
        if ($null -eq $timestamps -or $ts.Count -gt $timestamps.Count) {
            $timestamps = $ts
        }
        $allData[$t] = @{
            Timestamps = $ts
            Prices = $adjClose
        }
    } else {
        Write-Host "FAILED"
    }
    Start-Sleep -Milliseconds 100
}

Write-Host "`nAligning dates and building master price matrix..."

# Convert timestamps to Date strings YYYY-MM-DD
$dates = @()
$epoch = [datetime]"1970-01-01 00:00:00"
foreach ($sec in $timestamps) {
    $d = $epoch.AddSeconds($sec).ToString("yyyy-MM-dd")
    $dates += $d
}

$numDays = $dates.Count
Write-Host "Total trading sessions detected: $numDays"

# Build CSV content
$header = "Date," + ($tickers -join ",")
$lines = @($header)

for ($i = 0; $i -lt $numDays; $i++) {
    $rowDate = $dates[$i]
    $rowVals = @($rowDate)
    $ts_target = $timestamps[$i]
    
    foreach ($t in $tickers) {
        $tData = $allData[$t]
        $idx = [array]::IndexOf($tData.Timestamps, $ts_target)
        if ($idx -ge 0 -and $null -ne $tData.Prices[$idx]) {
            $val = [string]$tData.Prices[$idx]
        } else {
            $val = ""
        }
        $rowVals += $val
    }
    $lines += ($rowVals -join ",")
}

$priceCsv = Join-Path $outDir "sp500_daily_prices_2015_2024.csv"
$lines | Out-File -FilePath $priceCsv -Encoding ascii
Write-Host "Saved prices to: $priceCsv"

# Compute log returns
Write-Host "Computing daily log returns..."
$retHeader = "Date," + ($tickers -join ",")
$retLines = @($retHeader)

for ($i = 1; $i -lt $numDays; $i++) {
    $rowDate = $dates[$i]
    $rowVals = @($rowDate)
    
    foreach ($t in $tickers) {
        $tData = $allData[$t]
        $p_curr = $tData.Prices[$i]
        $p_prev = $tData.Prices[$i - 1]
        if ($null -ne $p_curr -and $null -ne $p_prev -and $p_prev -gt 0) {
            $ret = [math]::Log($p_curr / $p_prev)
            $rowVals += ("{0:F6}" -f $ret)
        } else {
            $rowVals += "0.000000"
        }
    }
    $retLines += ($rowVals -join ",")
}

$retCsv = Join-Path $outDir "sp500_daily_returns_2015_2024.csv"
$retLines | Out-File -FilePath $retCsv -Encoding ascii
Write-Host "Saved returns to: $retCsv ($($retLines.Count - 1) return periods)"
