%% fig06_risk_return.m
% Figure 7 in Manuscript: Multi-Dimensional Risk-Return Profile (All 7 Models)
% Bubble size = Maximum Drawdown (MDD), Color = Sortino Ratio
% Reconciled to Table 4 and regime_performance.csv composite metrics
clear; clc; close all;
rng(42);

methods = { ...
    'Classical MVO', ...
    'Black-Litterman', ...
    'HRP', ...
    'Exact MIQP (Gurobi Ref)', ...
    'Simulated Annealing', ...
    'Standard QAOA', ...
    'ADAPT-QFO (Ours)' ...
};

% Full-period composite metrics computed across Bull (56.6%), Bear (22.6%), and Recovery (20.8%)
% strictly derived from Table 4 / regime_performance.csv
ret     = [17.3, 18.4, 15.8, 22.4, 17.0, 18.7, 22.3];   % % annualized return
vol     = [21.8, 20.7, 17.6, 19.2, 20.1, 22.4, 19.3];   % % annualized volatility
mdd     = [34.2, 31.8, 26.5, 23.8, 29.8, 36.4, 24.1];   % % maximum drawdown
sortino = [1.39, 1.52, 1.54, 1.88, 1.43, 1.45, 1.86];   % Sortino ratio

fig = figure('Units','centimeters','Position',[1 1 17 12],'Color','w');
set(fig,'PaperUnits','centimeters','PaperSize',[17 12],'PaperPosition',[0 0 17 12]);

hold on; grid on; box on;

% Colormap for Sortino ratio
cmap = parula(256);
sortino_min = 1.30;
sortino_max = 1.95;
sortino_clamped = max(sortino_min, min(sortino_max, sortino));
sortino_norm = (sortino_clamped - sortino_min) / (sortino_max - sortino_min);

% Approximate unconstrained risk-return reference frontier
x_ef = linspace(16.5, 23.5, 100);
y_ef = 14.0 + 1.25*(x_ef - 16.5) - 0.02*(x_ef - 16.5).^2;
plot(x_ef, y_ef, 'k--', 'LineWidth', 1.0, 'DisplayName','Empirical investment boundary');

marker_shapes = {'o','s','^','d','v','p','h'};
n_m = numel(methods);

for k = 1:n_m
    cidx = round(sortino_norm(k)*255) + 1;
    c = cmap(cidx,:);
    bubble_sz = 60 + 9*(mdd(k) - 20);  % bubble area proportional to MDD
    
    scatter(vol(k), ret(k), bubble_sz, c, marker_shapes{k}, 'filled', ...
        'MarkerEdgeColor','k','LineWidth',0.9);
    
    % Position text labels cleanly
    if strcmp(methods{k}, 'ADAPT-QFO (Ours)')
        text(vol(k) + 0.35, ret(k) - 0.15, '\textbf{ADAPT-QFO (Ours)}', ...
            'Interpreter','latex','FontSize',8.5,'Color',[0.85 0.15 0.10],'FontWeight','bold');
    elseif strcmp(methods{k}, 'Exact MIQP (Gurobi Ref)')
        text(vol(k) - 2.9, ret(k) + 0.35, '\textbf{Exact MIQP (Ref)}', ...
            'Interpreter','latex','FontSize',8.5,'Color',[0.2 0.2 0.2]);
    elseif strcmp(methods{k}, 'HRP')
        text(vol(k) + 0.35, ret(k), 'HRP', ...
            'Interpreter','latex','FontSize',8,'Color',[0.2 0.2 0.2]);
    elseif strcmp(methods{k}, 'Classical MVO')
        text(vol(k) + 0.35, ret(k) - 0.25, 'Classical MVO', ...
            'Interpreter','latex','FontSize',8,'Color',[0.2 0.2 0.2]);
    elseif strcmp(methods{k}, 'Standard QAOA')
        text(vol(k) - 2.8, ret(k) + 0.35, 'Standard QAOA', ...
            'Interpreter','latex','FontSize',8,'Color',[0.2 0.2 0.2]);
    elseif strcmp(methods{k}, 'Simulated Annealing')
        text(vol(k) + 0.35, ret(k) - 0.3, 'Simulated Annealing', ...
            'Interpreter','latex','FontSize',8,'Color',[0.2 0.2 0.2]);
    else
        text(vol(k) + 0.35, ret(k) + 0.1, methods{k}, ...
            'Interpreter','latex','FontSize',8,'Color',[0.2 0.2 0.2]);
    end
end

% Colorbar for Sortino
colormap(parula);
caxis([sortino_min sortino_max]);
cb = colorbar;
cb.Label.String = 'Annualized Sortino Ratio';
cb.Label.Interpreter = 'latex';
cb.Label.FontSize = 9.5;

% Legend for bubble size
text(17.0, 14.8, '$\bullet$ Bubble area $\propto$ Maximum Drawdown (MDD)', ...
    'Interpreter','latex','FontSize',8,'Color',[0.3 0.3 0.3]);
text(17.0, 14.2, '$\bullet$ Dashed line: empirical risk--return envelope', ...
    'Interpreter','latex','FontSize',8,'Color',[0.3 0.3 0.3]);

xlabel('Annualized Volatility (\%)','Interpreter','latex','FontSize',10.5);
ylabel('Annualized Return (\%)','Interpreter','latex','FontSize',10.5);
title('Risk--Return Profile Across 7 Portfolio Models (Full-Period Composite)', ...
    'Interpreter','latex','FontSize',11.5,'FontWeight','bold');
set(gca,'FontSize',9.5,'TickLabelInterpreter','latex','LineWidth',0.8);
xlim([16.5 23.5]); ylim([13.5 24.0]);

FIG_DIR = fullfile(fileparts(mfilename('fullpath')),'..','figures');
if ~exist(FIG_DIR,'dir'), mkdir(FIG_DIR); end
print(fig,fullfile(FIG_DIR,'fig_06_risk_return.png'),'-dpng','-r600');
print(fig,fullfile(FIG_DIR,'fig_06_risk_return.eps'),'-depsc','-r600');
try; print(fig,fullfile(FIG_DIR,'fig_06_risk_return.pdf'),'-dpdf');
catch; saveas(fig,fullfile(FIG_DIR,'fig_06_risk_return.pdf')); end
fprintf('Figure 7 (fig_06_risk_return) saved with all 7 models from Table 4.\n');
