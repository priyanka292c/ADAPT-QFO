%% fig02_qubo_mapping.m
% Figure 2: QUBO Matrix Heatmap for 20-asset Portfolio
rng(42);
n = 20;

% Generate realistic QUBO matrix Q for portfolio optimization
% Q_ij = lambda_r * sigma_ij - lambda_mu * mu_i*delta_ij + penalty terms
mu_a = 0.08 + 0.12*rand(n,1);
sigma_a = 0.10 + 0.20*rand(n,1);
rho = generate_corr_matrix2(n, 0.35);
Sigma_a = diag(sigma_a)*rho*diag(sigma_a);

lambda_r  = 1.5;   % risk penalty
lambda_mu = 1.0;   % return weight
lambda_b  = 5.0;   % budget constraint penalty
K = 5;             % cardinality target

Q = zeros(n);
for i = 1:n
    for j = 1:n
        Q(i,j) = lambda_r * Sigma_a(i,j);
    end
    Q(i,i) = Q(i,i) - lambda_mu*mu_a(i) + lambda_b*(1 - 2/K);
end
for i = 1:n
    for j = (i+1):n
        Q(i,j) = Q(i,j) + 2*lambda_b/K^2;
        Q(j,i) = Q(i,j);
    end
end

% ── Plot ─────────────────────────────────────────────────────────────────
fig = figure('Units','centimeters','Position',[1 1 14 12],'Color','w');
set(fig,'PaperUnits','centimeters','PaperSize',[14 12],'PaperPosition',[0 0 14 12]);

imagesc(Q);
colormap(redwhiteblue_cmap(256));
cb = colorbar;
cb.Label.String = 'QUBO Coefficient $Q_{ij}$';
cb.Label.Interpreter = 'latex';
cb.Label.FontSize = 10;

hold on;
% Highlight diagonal (self-terms)
for i = 1:n
    rectangle('Position',[i-0.5 i-0.5 1 1],'EdgeColor','k','LineWidth',1.2);
end

% Annotate quadrants
plot([0.5 n+0.5],[n+0.5 n+0.5],'k-','LineWidth',0.5);
text(n/2, 0.2, 'Risk ($\lambda_r \Sigma_{ij}$)', ...
    'Interpreter','latex','FontSize',8,'HorizontalAlignment','center');
text(0.2, n/2, 'Return', 'Interpreter','latex','FontSize',8, ...
    'HorizontalAlignment','center','Rotation',90);

xlabel('Asset Index $j$','Interpreter','latex','FontSize',11);
ylabel('Asset Index $i$','Interpreter','latex','FontSize',11);
title('QUBO Matrix $Q$ for 20-Asset Portfolio Optimization', ...
    'Interpreter','latex','FontSize',12);
set(gca,'FontSize',10,'TickLabelInterpreter','latex', ...
    'XTick',1:2:n,'YTick',1:2:n,'LineWidth',0.8);
axis square;

% Sparsity annotation (explicitly labeled pre-pruning)
nz = nnz(abs(Q)>0.001);
text(1, n-0.5, sprintf('Dense (Pre-pruning) NNZ: %d / %d (%.0f\\%%)', nz, n^2, 100*nz/n^2), ...
    'Interpreter','latex','FontSize',7.5,'Color','w');

FIG_DIR = fullfile(fileparts(mfilename('fullpath')),'..','figures');
if ~exist(FIG_DIR,'dir'), mkdir(FIG_DIR); end
export_fig_pub2(fig, fullfile(FIG_DIR,'fig_02_qubo_mapping'));
fprintf('Figure 2 saved.\n');

%% ── Helpers ──────────────────────────────────────────────────────────────
function C = generate_corr_matrix2(n, avg_rho)
    A = randn(n,n); C = A*A'/n;
    C = C + avg_rho*ones(n);
    C = C ./ (diag(C).^0.5 * diag(C)'.^0.5);
    C = (C+C')/2 + (0.05-min(eig(C)))*eye(n);
    C = C ./ (diag(C).^0.5 * diag(C)'.^0.5);
end

function cmap = redwhiteblue_cmap(n)
    r = [linspace(0.7,1,n/2), linspace(1,0.1,n/2)]';
    g = [linspace(0.1,1,n/2), linspace(1,0.1,n/2)]';
    b = [linspace(0.1,1,n/2), linspace(1,0.7,n/2)]';
    cmap = [r g b];
end

function export_fig_pub2(fig, fpath)
    print(fig,[fpath '.png'],'-dpng','-r600');
    print(fig,[fpath '.eps'],'-depsc','-r600');
    try; print(fig,[fpath '.pdf'],'-dpdf'); catch; saveas(fig,[fpath '.pdf']); end
end
