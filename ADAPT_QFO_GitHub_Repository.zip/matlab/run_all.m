%% run_all.m — Master script: ADAPT-QFO Paper Figure Generation
% Runs all figure scripts sequentially in isolated scopes and exports all figures.

function run_all()
    clc; close all;
    rng(42);   % reproducibility

    BASE = fileparts(mfilename('fullpath'));
    addpath(genpath(BASE));

    FIG_DIR = fullfile(BASE, '..', 'figures');
    if ~exist(FIG_DIR, 'dir'), mkdir(FIG_DIR); end

    fprintf('=== ADAPT-QFO Figure Generation Pipeline ===\n');
    fprintf('Output directory: %s\n\n', FIG_DIR);

    scripts = {
        'fig01_efficient_frontier.m';
        'fig02_qubo_mapping.m';
        'fig03_circuit_depth.m';
        'fig04_convergence.m';
        'fig05_sharpe_comparison.m';
        'fig06_risk_return.m';
        'fig07_heatmap_correlation.m';
        'fig08_qubit_scaling.m';
        'fig09_noise_sensitivity.m';
        'fig10_portfolio_weights.m';
    };

    for k = 1:numel(scripts)
        sname = scripts{k};
        fprintf('[%02d/%02d] Running %s ... ', k, numel(scripts), sname);
        try
            run_isolated(fullfile(BASE, sname));
            fprintf('OK\n');
        catch ME
            fprintf('ERROR: %s\n', ME.message);
        end
        close all;
    end

    fprintf('\nAll figures generated. Running export...\n');
    try
        run_isolated(fullfile(BASE, 'export_all_figures.m'));
        fprintf('OK\n');
    catch ME
        fprintf('ERROR: %s\n', ME.message);
    end
    fprintf('\n=== Pipeline Complete ===\n');
end

function run_isolated(script_path)
    run(script_path);
end
