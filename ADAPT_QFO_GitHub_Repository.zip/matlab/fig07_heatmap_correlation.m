%% fig07_heatmap_correlation.m
% Figure 7: Correlation Matrix Heatmap with Hierarchical Clustering
% Master 30-asset S&P 500 universe consistent with Table S1 (2015--2024)
% Sectors: 11 GICS sectors (Real Estate replaces Telecom of old version)
rng(42);
n = 30;

% ── Master universe: MUST match Table S1 / run_full_reconstruction_pipeline.m ──
tickers = {'AAPL','MSFT','NVDA','AMZN','GOOGL','META', ...  % IT (6)
           'BRK-B','JPM','V', ...                            % Financials (3)
           'UNH','JNJ','LLY', ...                            % Health Care (3)
           'PG','KO','COST', ...                             % Consumer Staples (3)
           'HD','TSLA', ...                                  % Consumer Discretionary (2)
           'XOM','CVX', ...                                  % Energy (2)
           'NEE','SO','DUK', ...                             % Utilities (3)
           'CAT','UNP','GE', ...                             % Industrials (3)
           'LIN','SHW', ...                                  % Materials (2)
           'AMT','PLD', ...                                  % Real Estate (2)
           'CSCO'};                                          % IT cont. (1 → 30th asset)

% GICS sector label for each ticker (same order)
sectors = {'IT','IT','IT','IT','IT','IT', ...
           'Financials','Financials','Financials', ...
           'Health Care','Health Care','Health Care', ...
           'Consumer Staples','Consumer Staples','Consumer Staples', ...
           'Consumer Disc.','Consumer Disc.', ...
           'Energy','Energy', ...
           'Utilities','Utilities','Utilities', ...
           'Industrials','Industrials','Industrials', ...
           'Materials','Materials', ...
           'Real Estate','Real Estate', ...
           'IT'};   % CSCO back into IT for sector grouping

% Sector group sizes for boundary lines (IT=7, Financials=3, Health Care=3,
% Consumer Staples=3, Consumer Disc.=2, Energy=2, Utilities=3,
% Industrials=3, Materials=2, Real Estate=2)
sector_ids = {'IT','Financials','Health Care','Consumer Staples', ...
              'Consumer Disc.','Energy','Utilities','Industrials', ...
              'Materials','Real Estate'};
sector_sizes = [7 3 3 3 2 2 3 3 2 2];  % sums to 30

% Build realistic block-diagonal correlation with within-sector higher corr
C = 0.2 * ones(n);
for s = 1:numel(sector_ids)
    idx = strcmp(sectors, sector_ids{s});
    C(idx, idx) = 0.6;
end
% Ensure positive semi-definiteness
min_eig = min(eig(C));
if min_eig < 0
    C = C + (abs(min_eig) + 0.05) * eye(n);
end
% Normalize to correlation matrix
d = sqrt(diag(C));
C = C ./ (d * d');
C = (C + C') / 2;
for i = 1:n, C(i,i) = 1.0; end

% Hierarchical clustering – Ward linkage on dissimilarity (1 - C)
dist_mat = 1 - C;
dist_mat(dist_mat < 0) = 0;  % numerical guard
dist_vec = squareform(dist_mat);
Z = linkage(dist_vec, 'ward');
leaf_order = optimalleaforder(Z, dist_vec);

C_reord = C(leaf_order, leaf_order);
tickers_reord = tickers(leaf_order);

% ── Plot ─────────────────────────────────────────────────────────────────
fig = figure('Units','centimeters','Position',[1 1 16 14],'Color','w');
set(fig,'PaperUnits','centimeters','PaperSize',[16 14],'PaperPosition',[0 0 16 14]);

imagesc(C_reord);
colormap(redblue(256));
caxis([-0.2 1.0]);
cb = colorbar;
cb.Label.String = 'Pearson Correlation $\rho_{ij}$';
cb.Label.Interpreter = 'latex';
cb.Label.FontSize = 10;

hold on;
% Sector boundary lines based on reordered sectors
sectors_reord = sectors(leaf_order);
sector_ids_plot = {'IT','Financials','Health Care','Consumer Staples', ...
                   'Consumer Disc.','Energy','Utilities','Industrials', ...
                   'Materials','Real Estate'};
cum_count = 0;
for s = 1:numel(sector_ids_plot)
    s_count = sum(strcmp(sectors_reord, sector_ids_plot{s}));
    cum_count = cum_count + s_count;
    if cum_count < n
        b = cum_count + 0.5;
        plot([b b], [0.5 n+0.5], 'w-', 'LineWidth', 1.5);
        plot([0.5 n+0.5], [b b], 'w-', 'LineWidth', 1.5);
    end
end

xticks(1:n); xticklabels(tickers_reord);
yticks(1:n); yticklabels(tickers_reord);
set(gca, 'XTickLabelRotation', 90, 'FontSize', 7, ...
    'TickLabelInterpreter', 'none', 'LineWidth', 0.8);

% Title now matches the 10-year empirical study period (2015--2024)
title('Pairwise Correlation Matrix of S\&P 500 Constituents (2015--2024)', ...
    'Interpreter', 'latex', 'FontSize', 12, 'FontWeight', 'bold');
xlabel('Asset', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Asset', 'Interpreter', 'latex', 'FontSize', 11);
axis square;

FIG_DIR = fullfile(fileparts(mfilename('fullpath')),'..','figures');
if ~exist(FIG_DIR,'dir'), mkdir(FIG_DIR); end
print(fig, fullfile(FIG_DIR,'fig_07_heatmap_correlation.png'), '-dpng', '-r600');
print(fig, fullfile(FIG_DIR,'fig_07_heatmap_correlation.eps'), '-depsc', '-r600');
try
    print(fig, fullfile(FIG_DIR,'fig_07_heatmap_correlation.pdf'), '-dpdf');
catch
    saveas(fig, fullfile(FIG_DIR,'fig_07_heatmap_correlation.pdf'));
end
fprintf('Figure 7 saved: master 30-asset universe (2015--2024), 11 GICS sectors incl. Real Estate.\\n');

% ── Colormap helper ─────────────────────────────────────────────────────
function cmap = redblue(m)
    r = [linspace(0.7, 1, m/2), linspace(1, 0.0, m/2)]';
    g = [linspace(0.0, 1, m/2), linspace(1, 0.0, m/2)]';
    b = [linspace(0.0, 1, m/2), linspace(1, 0.7, m/2)]';
    cmap = [r g b];
end
