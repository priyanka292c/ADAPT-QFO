%% export_all_figures.m
% Exports all figures and generates a manifest CSV

BASE    = fileparts(mfilename('fullpath'));
FIG_DIR = fullfile(BASE, '..', 'figures');

captions = {
    'fig_01_efficient_frontier',   'Classical MVO vs. ADAPT-QFO Efficient Frontier with 22% Sharpe improvement';
    'fig_02_qubo_mapping',         'QUBO matrix heatmap for 20-asset portfolio showing penalty structure';
    'fig_03_circuit_depth',        'Circuit depth vs. number of assets for four ansatz methods';
    'fig_04_convergence',          'Optimizer convergence curves with 95% confidence intervals (30 runs)';
    'fig_05_sharpe_comparison',    'Grouped bar chart of Sharpe ratios across 6 methods and 3 market regimes';
    'fig_06_risk_return',          'Risk-return scatter bubble plot with MDD size and Sortino color encoding';
    'fig_07_heatmap_correlation',  'Pearson correlation heatmap with hierarchical clustering for 30 S&P 500 assets';
    'fig_08_qubit_scaling',        'Computational time vs. asset count on log scale with quantum utility threshold';
    'fig_09_noise_sensitivity',    'Sharpe ratio vs. depolarizing noise level for ADAPT-QFO and baselines';
    'fig_10_portfolio_weights',    'Monthly portfolio weight evolution 2020-2024 for ADAPT-QFO vs. MVO';
};

fid = fopen(fullfile(FIG_DIR,'figure_manifest.csv'),'w');
fprintf(fid,'Figure,Filename,Formats,Caption\n');

for k = 1:size(captions,1)
    fname = captions{k,1};
    cap   = captions{k,2};
    fmts  = '';
    for ext = {'.png','.eps','.pdf'}
        fp = fullfile(FIG_DIR, [fname ext{1}]);
        if exist(fp,'file'), fmts = [fmts ext{1} ';']; end
    end
    fprintf(fid,'%d,"%s","%s","%s"\n', k, fname, fmts, cap);
    fprintf('  Fig %02d: %s [%s]\n', k, fname, fmts);
end
fclose(fid);
fprintf('\nManifest written to figure_manifest.csv\n');
