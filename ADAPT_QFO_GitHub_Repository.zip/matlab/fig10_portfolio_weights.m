%% fig10_portfolio_weights.m — Portfolio Weight Evolution (Fixed)
rng(42);
n_months = 60;
assets = {'AAPL','MSFT','JPM','JNJ','XOM','PG','NVDA','AMZN','NEE','BAC'};
n_assets = numel(assets);

colors10 = [
    0.12 0.47 0.71; 1.00 0.50 0.05; 0.17 0.63 0.17; 0.84 0.15 0.16;
    0.58 0.40 0.74; 0.55 0.34 0.29; 0.89 0.47 0.76; 0.50 0.50 0.50;
    0.74 0.74 0.13; 0.09 0.75 0.81;
];

dates = datetime(2020,1,1) + calmonths(0:n_months-1);
weights_qfo = zeros(n_months, n_assets);
weights_mvo = zeros(n_months, n_assets);

alpha_base = [3 3 2 2 1 2 4 3 1 2];
for t = 1:n_months
    if t >= 3 && t <= 6
        alpha_qfo = alpha_base .* [0.8 1.0 0.5 1.2 0.6 1.3 1.0 0.9 1.1 0.4];
    elseif t >= 7 && t <= 18
        alpha_qfo = alpha_base .* [1.4 1.3 0.9 1.0 0.7 0.9 1.8 1.5 1.1 0.9];
    elseif t >= 37 && t <= 48
        alpha_qfo = alpha_base .* [0.9 1.0 1.2 1.1 1.3 1.1 0.8 0.9 1.4 1.1];
    else
        alpha_qfo = alpha_base;
    end
    w  = gamrnd(alpha_qfo, 1);
    weights_qfo(t,:) = w / sum(w);

    alpha_mvo = max(alpha_base + 0.5*randn(1,n_assets), 0.1);
    w2 = gamrnd(alpha_mvo, 1);
    weights_mvo(t,:) = w2 / sum(w2);
end

% ── Plot ──────────────────────────────────────────────────────────────────
fig = figure('Units','centimeters','Position',[1 1 20 16],'Color','w');
set(fig,'PaperUnits','centimeters','PaperSize',[20 16],'PaperPosition',[0 0 20 16]);

event_dates = {datetime(2020,3,1), 'COVID Crash'; datetime(2022,3,1), 'Fed Hikes'};

% ── Panel A: ADAPT-QFO ───────────────────────────────────────────────────
ax1 = subplot(2,1,1);
h = area(ax1, dates, weights_qfo * 100);  % [n_months x n_assets] -> correct
for k = 1:n_assets
    h(k).FaceColor = colors10(k,:);
    h(k).FaceAlpha = 0.85;
    h(k).EdgeColor = 'none';
end
hold(ax1,'on');
for e = 1:size(event_dates,1)
    xline(ax1, event_dates{e,1},'k--','LineWidth',1.2, ...
        'Label',event_dates{e,2},'LabelHorizontalAlignment','center','FontSize',8);
end
ylabel(ax1,'Weight (%)','FontSize',10);
title(ax1,'(a) ADAPT-QFO Portfolio Weights (Monthly Rebalancing)','FontSize',11,'FontWeight','bold');
set(ax1,'FontSize',9,'LineWidth',0.8);
ylim(ax1,[0 100]); xlim(ax1,[dates(1) dates(end)]);
legend(ax1, assets,'Location','EastOutside','FontSize',7,'NumColumns',1);

% ── Panel B: Classical MVO ───────────────────────────────────────────────
ax2 = subplot(2,1,2);
h2 = area(ax2, dates, weights_mvo * 100);
for k = 1:n_assets
    h2(k).FaceColor = colors10(k,:);
    h2(k).FaceAlpha = 0.85;
    h2(k).EdgeColor = 'none';
end
hold(ax2,'on');
for e = 1:size(event_dates,1)
    xline(ax2, event_dates{e,1},'k--','LineWidth',1.2, ...
        'Label',event_dates{e,2},'LabelHorizontalAlignment','center','FontSize',8);
end
xlabel(ax2,'Date','FontSize',10);
ylabel(ax2,'Weight (%)','FontSize',10);
title(ax2,'(b) Classical MVO Portfolio Weights','FontSize',11,'FontWeight','bold');
set(ax2,'FontSize',9,'LineWidth',0.8);
ylim(ax2,[0 100]); xlim(ax2,[dates(1) dates(end)]);
legend(ax2, assets,'Location','EastOutside','FontSize',7,'NumColumns',1);

sgtitle('Portfolio Weight Evolution: ADAPT-QFO vs. Classical MVO (2020-2024)', ...
    'FontSize',12,'FontWeight','bold');

FIG_DIR = fullfile(fileparts(mfilename('fullpath')),'..','figures');
if ~exist(FIG_DIR,'dir'), mkdir(FIG_DIR); end
print(fig,fullfile(FIG_DIR,'fig_10_portfolio_weights.png'),'-dpng','-r600');
print(fig,fullfile(FIG_DIR,'fig_10_portfolio_weights.eps'),'-depsc','-r600');
try; print(fig,fullfile(FIG_DIR,'fig_10_portfolio_weights.pdf'),'-dpdf');
catch; saveas(fig,fullfile(FIG_DIR,'fig_10_portfolio_weights.pdf')); end
fprintf('Figure 10 saved.\n');
