%% verify_consistency.m
%% Comprehensive Scientific Integrity Gate and Cross-Document Consistency Audit
% Adheres to Non-negotiable Scientific Reproducibility Rule (Item 0)

fprintf('========================================================================\n');
fprintf('       SCIENTIFIC INTEGRITY GATE & REPRODUCIBILITY AUDIT               \n');
fprintf('========================================================================\n\n');

data_dir = 'd:\Quantum finance\paper_output\benchmarks\data\';
paper_dir = 'd:\Quantum finance\paper_output\';

all_passed = true;

%% -------------------------------------------------------------------------
%% 1. NUMERICAL & DATA INTEGRITY CHECKS
%% -------------------------------------------------------------------------
fprintf('--- GATE 1: CSV Data Generation & Numerical Validity ---\n');

csv_files = {
    'apel_dct_energy.csv', ...
    'asset_universe.csv', ...
    'circuit_scaling.csv', ...
    'crossover_projection.csv', ...
    'nahea_pruning_bounds.csv', ...
    'qpas_attributions.csv', ...
    'regime_performance.csv', ...
    'statistical_tests.csv'
};

for i = 1:length(csv_files)
    fpath = fullfile(data_dir, csv_files{i});
    if ~isfile(fpath)
        fprintf('  [FAIL] Missing CSV file: %s\n', csv_files{i});
        all_passed = false;
    else
        opts = detectImportOptions(fpath);
        if strcmp(csv_files{i}, 'regime_performance.csv')
            opts = setvartype(opts, 'string');
        end
        tbl = readtable(fpath, opts);
        % Check for NaN or Inf in numeric columns
        num_cols = varfun(@isnumeric, tbl, 'OutputFormat', 'uniform');
        has_nan = false;
        has_inf = false;
        for c = find(num_cols)
            vals = tbl{:, c};
            if any(isnan(vals))
                has_nan = true;
            end
            if any(isinf(vals))
                has_inf = true;
            end
        end
        if has_nan || has_inf
            fprintf('  [FAIL] %s contains NaN or Inf!\n', csv_files{i});
            all_passed = false;
        else
            fprintf('  [PASS] %s (%d rows, valid numeric data)\n', csv_files{i}, height(tbl));
        end
    end
end

%% -------------------------------------------------------------------------
%% 2. MATHEMATICAL & OPTIMIZATION EQUIVALENCE CHECKS
%% -------------------------------------------------------------------------
fprintf('\n--- GATE 2: Physics, QUBO & Optimization Equivalence ---\n');

% 2.1 QUBO vs MIQP Objective Equivalence
% Test on a representative small instance: n=4, K=2
n_test = 4;
K_test = 2;
lambda_r = 1.5;
lambda_mu = 1.0;
lambda_b = 5.0;
Sigma_test = [0.04, 0.01, 0.015, 0.008;
              0.01, 0.05, 0.02,  0.012;
              0.015, 0.02, 0.06, 0.018;
              0.008, 0.012, 0.018, 0.045];
mu_test = [0.12; 0.15; 0.18; 0.10];

Q_test = zeros(n_test, n_test);
for i = 1:n_test
    for j = 1:n_test
        if i == j
            Q_test(i,i) = (lambda_r/2) * Sigma_test(i,i) - lambda_mu * mu_test(i) + lambda_b * (1 - 2*K_test);
        else
            Q_test(i,j) = (lambda_r/2) * Sigma_test(i,j) + lambda_b;
        end
    end
end
% Check symmetry
symm_diff = norm(Q_test - Q_test', 'fro');
if symm_diff < 1e-12
    fprintf('  [PASS] QUBO matrix symmetry verified (diff = %.2e)\n', symm_diff);
else
    fprintf('  [FAIL] QUBO matrix is asymmetric!\n');
    all_passed = false;
end

% Check equivalence across all 2^n configurations
all_equiv = true;
max_dev = 0;
for dec = 0:(2^n_test - 1)
    x = bitget(dec, 1:n_test)';
    c_miqp = (lambda_r/2) * (x' * Sigma_test * x) - lambda_mu * (mu_test' * x) + lambda_b * (sum(x) - K_test)^2;
    h_qubo = x' * Q_test * x + lambda_b * K_test^2;
    dev = abs(h_qubo - c_miqp);
    if dev > max_dev
        max_dev = dev;
    end
    if dev > 1e-10
        all_equiv = false;
    end
end
if all_equiv
    fprintf('  [PASS] Exact QUBO-MIQP objective equivalence verified (max dev = %.2e < 1e-10)\n', max_dev);
else
    fprintf('  [FAIL] QUBO-MIQP objective mismatch: max dev = %.2e\n', max_dev);
    all_passed = false;
end

% 2.2 APEL Mathematical Identity: delta_k = sqrt(1 - eta_k)
apel_tbl = readtable(fullfile(data_dir, 'apel_dct_energy.csv'));
eta = apel_tbl.FrobeniusEnergy_Median;
delta = apel_tbl.RelFrobeniusError_Median;
delta_calc = sqrt(max(0, 1 - eta));
max_frob_dev = max(abs(delta - delta_calc));
if max_frob_dev < 1e-4
    fprintf('  [PASS] APEL Frobenius identity delta_k = sqrt(1 - eta_k) holds (max dev = %.2e)\n', max_frob_dev);
else
    fprintf('  [FAIL] APEL Frobenius identity violated: max dev = %.2e\n', max_frob_dev);
    all_passed = false;
end

% 2.3 NAHEA Pruning Ground State Preservation Condition: 2 * eps < Delta_gap
nahea_tbl = readtable(fullfile(data_dir, 'nahea_pruning_bounds.csv'));
gap_ok = all(nahea_tbl.RatioEpsToGap < 0.5);
if gap_ok
    fprintf('  [PASS] NAHEA ground-state preservation verified: 2*eps_prune < Delta_gap for all instances (max ratio = %.4f < 0.5)\n', max(nahea_tbl.RatioEpsToGap));
else
    fprintf('  [FAIL] NAHEA ground-state preservation condition violated!\n');
    all_passed = false;
end

%% -------------------------------------------------------------------------
%% 3. QUANTUM HARDWARE & CIRCUIT SCALING INTEGRITY
%% -------------------------------------------------------------------------
fprintf('\n--- GATE 3: Quantum Architecture & Circuit Scaling ---\n');

circuit_tbl = readtable(fullfile(data_dir, 'circuit_scaling.csv'));
% Verify Class A (n <= 27) vs Class B (n >= 28)
class_A_ok = all(strcmp(circuit_tbl.ExperimentClass(circuit_tbl.Assets_n <= 27), 'Class A (Kyoto 27Q)'));
class_B_ok = all(strcmp(circuit_tbl.ExperimentClass(circuit_tbl.Assets_n >= 28), 'Class B (Extended Simulator)'));
if class_A_ok && class_B_ok
    fprintf('  [PASS] Experiment Class bifurcation verified: Class A (n<=27 Kyoto) vs Class B (n>=28 Extended Sim)\n');
else
    fprintf('  [FAIL] Incorrect experiment classification in circuit scaling table!\n');
    all_passed = false;
end

% Verify 37.4% circuit depth reduction at n=30
depth_qaoa_30 = circuit_tbl.Depth2Q_StdQAOA(circuit_tbl.Assets_n == 30);
depth_adapt_30 = circuit_tbl.Depth2Q_ADAPTQFO(circuit_tbl.Assets_n == 30);
depth_red_30 = (1 - depth_adapt_30 / depth_qaoa_30) * 100;
if abs(depth_red_30 - 37.37) < 0.2
    fprintf('  [PASS] Two-qubit depth reduction verified: %.1f%% (from %d to %d)\n', depth_red_30, depth_qaoa_30, depth_adapt_30);
else
    fprintf('  [FAIL] Depth reduction is %.1f%% (expected 37.4%%)\n', depth_red_30);
    all_passed = false;
end

% Verify CNOT reduction at n=30: 1580 -> 812 (48.6%)
cnot_qaoa_30 = circuit_tbl.CNOT_StdQAOA(circuit_tbl.Assets_n == 30);
cnot_adapt_30 = circuit_tbl.CNOT_ADAPTQFO(circuit_tbl.Assets_n == 30);
cnot_red_30 = (1 - cnot_adapt_30 / cnot_qaoa_30) * 100;
if abs(cnot_red_30 - 48.6) < 0.2
    fprintf('  [PASS] CNOT reduction verified: %.1f%% (from %d to %d)\n', cnot_red_30, cnot_qaoa_30, cnot_adapt_30);
else
    fprintf('  [FAIL] CNOT reduction is %.1f%% (expected 48.6%%)\n', cnot_red_30);
    all_passed = false;
end

%% -------------------------------------------------------------------------
%% 4. STATISTICAL VALIDITY CHECKS
%% -------------------------------------------------------------------------
fprintf('\n--- GATE 4: Statistical Testing & Hypothesis Consistency ---\n');

stat_tbl = readtable(fullfile(data_dir, 'statistical_tests.csv'));
miqp_row = stat_tbl(strcmp(stat_tbl.BenchmarkModel, 'Exact MIQP (Gurobi Ref)'), :);
if ~isempty(miqp_row) && abs(miqp_row.P_Value - 0.337) < 0.01 && abs(miqp_row.DM_Statistic - 0.42) < 0.01
    fprintf('  [PASS] MIQP statistical equivalence verified: DM = %.2f, p = %.3f (n.s., MIP Gap=0)\n', miqp_row.DM_Statistic, miqp_row.P_Value);
else
    fprintf('  [FAIL] MIQP statistical test values inconsistent!\n');
    all_passed = false;
end

benchmarks_p = stat_tbl.P_Value(~strcmp(stat_tbl.BenchmarkModel, 'Exact MIQP (Gurobi Ref)'));
if all(benchmarks_p < 0.001)
    fprintf('  [PASS] Heuristic & conventional benchmarks outperformance verified: all p < 0.001 (max p = %.2e)\n', max(benchmarks_p));
else
    fprintf('  [FAIL] Non-MIQP benchmarks p-values not all < 0.001!\n');
    all_passed = false;
end

%% -------------------------------------------------------------------------
%% 5. CROSS-DOCUMENT SYNCHRONIZATION AUDIT
%% -------------------------------------------------------------------------
fprintf('\n--- GATE 5: Cross-Document Text & Numerical Synchronization ---\n');

docs = struct();
docs.main = fileread(fullfile(paper_dir, 'main.tex'));
docs.supp = fileread(fullfile(paper_dir, 'supplementary.tex'));
docs.cover = fileread(fullfile(paper_dir, 'cover_letter.tex'));
docs.abstract = fileread(fullfile(paper_dir, 'graphical_abstract.tex'));

doc_names = fieldnames(docs);

% 5.1 Title Uniformity
title_str = 'Noise-Aware Quantum Portfolio Optimization under NISQ Constraints';
fprintf('  Title uniformity:\n');
for i = 1:length(doc_names)
    dn = doc_names{i};
    has_t = contains(docs.(dn), title_str);
    fprintf('    %s: %s\n', dn, ternary(has_t, 'MATCH', 'MISMATCH'));
    if ~has_t; all_passed = false; end
end

% 5.2 Author Block Uniformity (main, supp, cover)
fprintf('  Author block uniformity:\n');
for dn_cell = {'main', 'supp', 'cover'}
    dn = dn_cell{1};
    has_a = contains(docs.(dn), 'Hamood Amur Al Wardi') && ...
            contains(docs.(dn), 'Uvesh Husain') && ...
            contains(docs.(dn), 'Shylaja H N') && ...
            contains(docs.(dn), 'Ram Soorat') && ...
            contains(docs.(dn), 'Priyanka') && ...
            contains(docs.(dn), 'Afzalur Rahman');
    fprintf('    %s: %s\n', dn, ternary(has_a, 'COMPLETE', 'INCOMPLETE'));
    if ~has_a; all_passed = false; end
end

% 5.3 Performance Metrics Consistency (Sharpe ratios)
% Bull: 1.47, Bear: 0.41, Recovery: 1.73; MVO Bear: 0.31
fprintf('  Sharpe ratio uniformity (1.47, 0.41, 1.73, MVO Bear 0.31):\n');
for dn_cell = {'main', 'supp', 'cover'}
    dn = dn_cell{1};
    has_sr = contains(docs.(dn), '1.47') && contains(docs.(dn), '0.41') && ...
             contains(docs.(dn), '1.73') && contains(docs.(dn), '0.31');
    fprintf('    %s: %s\n', dn, ternary(has_sr, 'MATCH', 'MISMATCH'));
    if ~has_sr; all_passed = false; end
end

% 5.4 Two-qubit depth reduction: exactly 37.4% (and NO stale 68% claims)
fprintf('  Circuit depth reduction (37.4%%, zero 68%% claims):\n');
for i = 1:length(doc_names)
    dn = doc_names{i};
    has_374 = contains(docs.(dn), '37.4');
    has_bad_68 = contains(docs.(dn), '68%') || contains(docs.(dn), '68.2%') || contains(docs.(dn), '68\%');
    fprintf('    %s: has 37.4%% = %s, has stale 68%% = %s\n', dn, ...
        ternary(has_374, 'YES', 'NO'), ternary(has_bad_68, 'YES (FAIL)', 'NO (CLEAN)'));
    if has_bad_68 || ~has_374; all_passed = false; end
end

% 5.5 Zero direct physical execution claims
fprintf('  Zero false physical hardware claims (all marked as simulation):\n');
for i = 1:length(doc_names)
    dn = doc_names{i};
    has_bad_phys = contains(lower(docs.(dn)), 'executed on the physical ibm kyoto') || ...
                   contains(lower(docs.(dn)), 'physical kyoto hardware execution');
    fprintf('    %s: %s\n', dn, ternary(has_bad_phys, 'FAIL (contains false physical claim)', 'CLEAN (properly marked as simulation)'));
    if has_bad_phys; all_passed = false; end
end

% 5.6 Zero stale n* approx 87 in graphical abstract
has_stale_n87 = contains(docs.abstract, '87') && contains(docs.abstract, 'crossover');
fprintf('  Graphical abstract clean of fixed n* = 87: %s\n', ternary(~has_stale_n87, 'CLEAN', 'FAIL'));
if has_stale_n87; all_passed = false; end

% 5.7 Zero causal claims for QPAS (must be objective-decomposition surrogate)
has_causal_abstract = contains(lower(docs.abstract), 'causal attribution');
fprintf('  Graphical abstract clean of causal attribution claims: %s\n', ternary(~has_causal_abstract, 'CLEAN', 'FAIL'));
if has_causal_abstract; all_passed = false; end

%% -------------------------------------------------------------------------
%% SUMMARY
%% -------------------------------------------------------------------------
fprintf('\n========================================================================\n');
if all_passed
    fprintf('  ALL SCIENTIFIC INTEGRITY & CONSISTENCY CHECKS PASSED SUCCESSFULLY!   \n');
    fprintf('  Package is fully verified and ready for production compilation.      \n');
else
    fprintf('  VERIFICATION FAILED: One or more integrity gates did not pass!       \n');
end
fprintf('========================================================================\n');

function out = ternary(cond, a, b)
    if cond
        out = a;
    else
        out = b;
    end
end
