%% test_pipeline_recalc.m
% Verification and numerical computation test script for APEL, NAHEA, and MIQP

clear; clc;

% Load tickers and parameters
tickers = { ...
    'AAPL', 'Apple Inc.', 'Information Technology', 0.248, 0.224, 1.18; ...
    'MSFT', 'Microsoft Corp.', 'Information Technology', 0.252, 0.211, 1.12; ...
    'NVDA', 'NVIDIA Corp.', 'Information Technology', 0.486, 0.445, 1.74; ...
    'AMZN', 'Amazon.com Inc.', 'Consumer Discretionary', 0.221, 0.268, 1.25; ...
    'GOOGL', 'Alphabet Inc.', 'Communication Services', 0.194, 0.232, 1.08; ...
    'META', 'Meta Platforms Inc.', 'Communication Services', 0.218, 0.331, 1.29; ...
    'BRK-B', 'Berkshire Hathaway', 'Financials', 0.124, 0.156, 0.88; ...
    'JPM', 'JPMorgan Chase & Co.', 'Financials', 0.158, 0.228, 1.14; ...
    'V', 'Visa Inc.', 'Financials', 0.172, 0.194, 0.95; ...
    'UNH', 'UnitedHealth Group', 'Health Care', 0.185, 0.178, 0.72; ...
    'JNJ', 'Johnson & Johnson', 'Health Care', 0.079, 0.142, 0.54; ...
    'LLY', 'Eli Lilly and Co.', 'Health Care', 0.284, 0.239, 0.68; ...
    'PG', 'Procter & Gamble Co.', 'Consumer Staples', 0.094, 0.138, 0.52; ...
    'KO', 'The Coca-Cola Co.', 'Consumer Staples', 0.078, 0.135, 0.56; ...
    'COST', 'Costco Wholesale Corp.', 'Consumer Staples', 0.212, 0.179, 0.78; ...
    'HD', 'The Home Depot Inc.', 'Consumer Discretionary', 0.156, 0.202, 1.02; ...
    'TSLA', 'Tesla Inc.', 'Consumer Discretionary', 0.421, 0.528, 2.05; ...
    'XOM', 'Exxon Mobil Corp.', 'Energy', 0.082, 0.236, 0.92; ...
    'CVX', 'Chevron Corp.', 'Energy', 0.091, 0.241, 0.96; ...
    'NEE', 'NextEra Energy Inc.', 'Utilities', 0.114, 0.182, 0.62; ...
    'SO', 'The Southern Co.', 'Utilities', 0.092, 0.164, 0.48; ...
    'DUK', 'Duke Energy Corp.', 'Utilities', 0.074, 0.161, 0.46; ...
    'CAT', 'Caterpillar Inc.', 'Industrials', 0.168, 0.254, 1.22; ...
    'UNP', 'Union Pacific Corp.', 'Industrials', 0.135, 0.206, 0.94; ...
    'GE', 'General Electric Co.', 'Industrials', 0.084, 0.312, 1.28; ...
    'LIN', 'Linde plc', 'Materials', 0.162, 0.174, 0.84; ...
    'SHW', 'Sherwin-Williams Co.', 'Materials', 0.181, 0.218, 1.06; ...
    'AMT', 'American Tower Corp.', 'Real Estate', 0.112, 0.204, 0.74; ...
    'PLD', 'Prologis Inc.', 'Real Estate', 0.146, 0.228, 1.04; ...
    'CSCO', 'Cisco Systems Inc.', 'Information Technology', 0.142, 0.218, 0.98 ...
};

n_assets = size(tickers, 1);
rng(42, 'twister');

% Setup full 2516-day historical simulation
T_total = 2516;
sectors = tickers(:, 3);
[~, ~, sector_idx] = unique(sectors);

C = zeros(n_assets, n_assets);
for i = 1:n_assets
    for j = 1:n_assets
        if i == j
            C(i,j) = 1.0;
        elseif sector_idx(i) == sector_idx(j)
            C(i,j) = 0.65;
        else
            C(i,j) = 0.28;
        end
    end
end
C = (C + C') / 2;
[V_c, D_c] = eig(C);
D_c = max(D_c, 1e-4);
C = V_c * D_c * V_c';
C = diag(1./sqrt(diag(C))) * C * diag(1./sqrt(diag(C)));

vols_base = cell2mat(tickers(:, 5));
means_base = cell2mat(tickers(:, 4));

% Generate daily returns across full 2516 days
mu_daily = means_base / 252;
sigma_daily = diag(vols_base / sqrt(252)) * C * diag(vols_base / sqrt(252));
R_full = repmat(mu_daily', T_total, 1) + randn(T_total, n_assets) * chol(sigma_daily, 'lower')';

% Orthonormal DCT-II basis matrix
C_dct = zeros(n_assets, n_assets);
for k = 1:n_assets
    for j = 1:n_assets
        if k == 1
            alpha = 1 / sqrt(n_assets);
        else
            alpha = sqrt(2 / n_assets);
        end
        C_dct(k, j) = alpha * cos((pi * (2 * j - 1) * (k - 1)) / (2 * n_assets));
    end
end

% Compute rolling covariance matrices with 252-day window, stepping every 21 days
window_size = 252;
step = 21;
window_starts = 1:step:(T_total - window_size + 1);
num_windows = length(window_starts);

tau_k_all = zeros(num_windows, n_assets);
delta_k_all = zeros(num_windows, n_assets);
frob_energy_all = zeros(num_windows, n_assets);

for w = 1:num_windows
    idx_range = window_starts(w):(window_starts(w) + window_size - 1);
    R_win = R_full(idx_range, :);
    
    % Ledoit-Wolf shrinkage
    S_w = cov(R_win) * 252;
    mean_corr = (sum(sum(C)) - n_assets) / (n_assets * (n_assets - 1));
    F = mean_corr * ones(n_assets, n_assets);
    for i = 1:n_assets, F(i,i) = 1.0; end
    s_diag = sqrt(diag(S_w));
    F = diag(s_diag) * F * diag(s_diag);
    shrinkage = 0.182;
    Sigma_w = (1 - shrinkage) * S_w + shrinkage * F;
    
    Gamma_w = C_dct * Sigma_w * C_dct';
    tot_tr = trace(Sigma_w);
    tot_frob = norm(Sigma_w, 'fro');
    
    for k = 1:n_assets
        Pi_k = zeros(n_assets, n_assets);
        Pi_k(1:k, 1:k) = eye(k);
        Gamma_k = Pi_k * Gamma_w * Pi_k;
        Sigma_k = C_dct' * Gamma_k * C_dct;
        
        tau_k_all(w, k) = trace(Sigma_k) / tot_tr;
        delta_k_all(w, k) = norm(Sigma_w - Sigma_k, 'fro') / tot_frob;
        frob_energy_all(w, k) = norm(Gamma_k, 'fro')^2 / tot_frob^2;
    end
end

fprintf('=== Rolling Covariance APEL Analysis (%d windows) ===\n', num_windows);
fprintf('Mode k=8:\n');
p_tau_8 = prctile(tau_k_all(:, 8), [5, 25, 50, 75, 95]);
p_delta_8 = prctile(delta_k_all(:, 8), [5, 25, 50, 75, 95]);
p_frob_8 = prctile(frob_energy_all(:, 8), [5, 25, 50, 75, 95]);
fprintf('Trace Variance Ratio tau_8: 5th=%.4f, 25th=%.4f, Med=%.4f, 75th=%.4f, 95th=%.4f\n', p_tau_8);
fprintf('Rel Frobenius Error delta_8: 5th=%.4f, 25th=%.4f, Med=%.4f, 75th=%.4f, 95th=%.4f\n', p_delta_8);
fprintf('Frobenius Energy eta_8:     5th=%.4f, 25th=%.4f, Med=%.4f, 75th=%.4f, 95th=%.4f\n', p_frob_8);

fprintf('\nMode k=12:\n');
p_tau_12 = prctile(tau_k_all(:, 12), [5, 25, 50, 75, 95]);
p_delta_12 = prctile(delta_k_all(:, 12), [5, 25, 50, 75, 95]);
p_frob_12 = prctile(frob_energy_all(:, 12), [5, 25, 50, 75, 95]);
fprintf('Trace Variance Ratio tau_12: 5th=%.4f, 25th=%.4f, Med=%.4f, 75th=%.4f, 95th=%.4f\n', p_tau_12);
fprintf('Rel Frobenius Error delta_12: 5th=%.4f, 25th=%.4f, Med=%.4f, 75th=%.4f, 95th=%.4f\n', p_delta_12);
fprintf('Frobenius Energy eta_12:     5th=%.4f, 25th=%.4f, Med=%.4f, 75th=%.4f, 95th=%.4f\n', p_frob_12);

% Evaluate Hamiltonian Pauli term counts on full 30-qubit problem
Sigma_full = cov(R_full) * 252;
mu_full = mean(R_full)' * 252;
K_sel = 5; lambda_r = 1.5; lambda_mu = 1.0; lambda_b = 5.0;

Q = zeros(n_assets, n_assets);
for i = 1:n_assets
    for j = 1:n_assets
        if i == j
            Q(i,i) = lambda_r * Sigma_full(i,i) - lambda_mu * mu_full(i) + lambda_b * (1 - 2/K_sel);
        else
            Q(i,j) = lambda_r * Sigma_full(i,j) + (2 * lambda_b) / (K_sel^2);
        end
    end
end
Q = (Q + Q') / 2;

% Ising conversion
J = Q / 4;
for i = 1:n_assets, J(i,i) = 0; end
h = zeros(n_assets, 1);
for i = 1:n_assets
    h(i) = -0.5 * Q(i,i) - sum(Q(i, [1:(i-1), (i+1):n_assets])) / 4;
end

num_zz_uncompressed = sum(sum(abs(triu(J, 1)) > 1e-8));
num_z_uncompressed = sum(abs(h) > 1e-8);
total_pauli_uncompressed = num_zz_uncompressed + num_z_uncompressed;
fprintf('\n=== Hamiltonian Pauli Term Analysis ===\n');
fprintf('Uncompressed (n=30): ZZ terms = %d, Z terms = %d, Total Non-Identity Pauli Terms = %d\n', ...
    num_zz_uncompressed, num_z_uncompressed, total_pauli_uncompressed);

% APEL compressed at k=8:
Gamma_full = C_dct * Sigma_full * C_dct';
Pi_8 = zeros(n_assets, n_assets); Pi_8(1:8, 1:8) = eye(8);
Sigma_apel8 = C_dct' * (Pi_8 * Gamma_full * Pi_8) * C_dct;

Q_apel8 = zeros(n_assets, n_assets);
for i = 1:n_assets
    for j = 1:n_assets
        if i == j
            Q_apel8(i,i) = lambda_r * Sigma_apel8(i,i) - lambda_mu * mu_full(i) + lambda_b * (1 - 2/K_sel);
        else
            Q_apel8(i,j) = lambda_r * Sigma_apel8(i,j) + (2 * lambda_b) / (K_sel^2);
        end
    end
end
Q_apel8 = (Q_apel8 + Q_apel8') / 2;
J_apel8 = Q_apel8 / 4;
for i = 1:n_assets, J_apel8(i,i) = 0; end
h_apel8 = zeros(n_assets, 1);
for i = 1:n_assets
    h_apel8(i) = -0.5 * Q_apel8(i,i) - sum(Q_apel8(i, [1:(i-1), (i+1):n_assets])) / 4;
end

% Weak coupling pruning (NAHEA threshold at 0.05 * max|J|)
thresh = 0.05 * max(abs(J_apel8(:)));
num_zz_apel8 = sum(sum((abs(triu(J_apel8, 1)) >= thresh)));
num_z_apel8 = sum(abs(h_apel8) >= thresh);
total_pauli_apel8 = num_zz_apel8 + num_z_apel8;
reduction_ratio = (total_pauli_uncompressed - total_pauli_apel8) / total_pauli_uncompressed;

fprintf('APEL k=8 + NAHEA Pruned: Active ZZ terms = %d, Active Z terms = %d, Total Pauli Terms = %d\n', ...
    num_zz_apel8, num_z_apel8, total_pauli_apel8);
fprintf('Pauli Term Compression Ratio: %.2f%%\n', reduction_ratio * 100);

% MIQP vs QUBO Objective Equivalence Check
fprintf('\n=== MIQP vs QUBO Objective Equivalence Check ===\n');
test_instances = 100;
max_diff = 0;
% For binary x with sum(x) = K_sel:
% C_MIQP(x) = (lambda_r / 2) * x' * Sigma * x - lambda_mu * mu' * x
% H_QUBO(x) = x' * Q * x
% We check that H_QUBO(x) - C_MIQP(x) is identically constant for all sum(x) = K
C_offset = lambda_b * (1 - 2/K_sel) * K_sel + (2 * lambda_b / K_sel^2) * (K_sel * (K_sel - 1) / 2) * 2;
% Actually let's compute directly:
combs_test = nchoosek(1:n_assets, K_sel);
num_c = size(combs_test, 1);
sample_indices = round(linspace(1, num_c, test_instances));

diffs = zeros(test_instances, 1);
for idx = 1:test_instances
    x_test = zeros(n_assets, 1);
    x_test(combs_test(sample_indices(idx), :)) = 1;
    
    val_miqp = (lambda_r / 2) * (x_test' * Sigma_full * x_test) - lambda_mu * (mu_full' * x_test);
    val_qubo = x_test' * Q * x_test;
    diffs(idx) = val_qubo - val_miqp;
end
equiv_error = max(abs(diffs - mean(diffs)));
fprintf('Max |H_QUBO(x) - C_MIQP(x) - Offset| across %d test combinations = %.2e\n', test_instances, equiv_error);
if equiv_error < 1e-10
    fprintf('[PASS] Exact Mathematical Objective Equivalence Confirmed!\n');
else
    fprintf('[FAIL] Objective difference is not constant!\n');
end
