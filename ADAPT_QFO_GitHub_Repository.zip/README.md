# ADAPT-QFO: A Noise-Aware Hybrid Quantum-Classical Framework for Intelligent Portfolio Optimization

[![MATLAB](https://img.shields.io/badge/MATLAB-R2022b%2B-blue.svg)](https://www.mathworks.com/products/matlab.html)
[![Python](https://img.shields.io/badge/Python-3.9%2B-green.svg)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Verification](https://img.shields.io/badge/Integrity%20Gates-All%20Pass-brightgreen.svg)](matlab/verify_consistency.m)

Official research code and reproducibility data package for the manuscript:  
**"ADAPT-QFO: A Noise-Aware Hybrid Quantum-Classical Framework for Intelligent Portfolio Optimization"**  
*Submitted to Expert Systems with Applications (Elsevier)*

---

## Authors & Affiliations

- **Dr. Shylaja H N** ($^*$Corresponding Author)  
  *Manipal Institute of Commerce, Finance and Economics, Manipal Academy of Higher Education (MAHE), Manipal, Karnataka, India*  
  Email: [`shylaja.hn@manipal.edu`](mailto:shylaja.hn@manipal.edu)
- **Hamood Amur Al Wardi**  
  *Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman*  
  Email: [`omaniconsul@gmail.com`](mailto:omaniconsul@gmail.com)
- **Dr. Uvesh Husain**  
  *Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman*  
  Email: [`u78.husain@gmail.com`](mailto:u78.husain@gmail.com)
- **Dr. Ram Soorat**  
  *School of Technology, Woxsen University, Kamkole, Hyderabad, Telangana, India*  
  Email: [`rsoorat@gmail.com`](mailto:rsoorat@gmail.com)
- **Priyanka**  
  *Department of Physics and Astrophysics, University of Delhi, Delhi, India*  
  Email: [`priyanka292c@gmail.com`](mailto:priyanka292c@gmail.com)
- **Afzalur Rahman**  
  *School of Business, Woxsen University, Kamkole, Hyderabad, Telangana, India*  
  Email: [`afzalur.rahman@woxsen.edu.in`](mailto:afzalur.rahman@woxsen.edu.in)

---

## Overview

Portfolio optimization under institutional cardinality constraints is an NP-hard mixed-integer quadratic program (MIQP). While variational quantum algorithms such as QAOA offer theoretical potential for combinatorial selection, their execution on Noisy Intermediate-Scale Quantum (NISQ) processors suffers from deep entangling gate sequences, hardware decoherence, and lack of transparent decision attribution.

This repository provides the complete implementation of **ADAPT-QFO** (Adaptive Depth-Aware Transparent Quantum Finance Optimizer), an intelligent optimization and decision-support framework featuring:

1. **Dual-Track Problem Formulation:** Decouples combinatorial binary asset selection on the quantum register ($x_i \in \{0,1\}$, $n \le 27$ qubits) from continuous portfolio weight optimization ($\mathbf{w} \in \Delta^{K-1}$) evaluated classically via convex quadratic programming.
2. **Adaptive Pauli Encoding Layer (APEL):** Compresses high-dimensional empirical covariance matrices via orthonormal 2D Discrete Cosine Transform (DCT-II) spectral projections, capturing $53.42\%$ median trace energy with $k \le 8$ modes and $94.50\%$ with $k \le 27$ modes, reducing active two-qubit Hamiltonian terms while avoiding per-window eigendecomposition overhead.
3. **Noise-Aware Hardware-Efficient Ansatz (NAHEA):** Maps problem graphs directly onto heavy-hex simulator topologies by routing active interactions along noise-weighted low-error channels parameterized by a representative heavy-hex noise model (`HH-27-REF-A` / `KYOTO-27-REF-A`), cutting two-qubit gate depth by **37.4%** ($1{,}124 \to 704$) and CNOT count by **48.6%** ($1{,}580 \to 812$) at $n=30$. Open-system state fidelity under Aer simulation increases from $43.2\%$ to $\mathbf{71.8\%}$ at $n=16, p=2$.
4. **Quantum Portfolio Attribution Score (QPAS):** An exact $\mathcal{O}(K^2)$ polynomial-time objective-decomposition attribution surrogate validated against leave-one-out marginal contributions (Spearman $\rho = 0.82$, run consistency $\rho = 0.91$), backed by a tamper-evident SHA-256 Merkle audit trail for institutional compliance.
5. **Parametric Transaction Cost Sensitivity:** Evaluates net risk-adjusted returns across plausible annual turnover scenarios ($100\%$ to $400\%$), showing break-even turnover $\tau^* = 148.9\%$ under realistic institutional transaction costs (15 bps), with effective diversification bounded mathematically as $1 \le \mathrm{ENH} \le K$.

---

## Repository Structure

```
├── benchmarks/
│   └── data/                              # Empirical datasets and numerical simulation results
│       ├── asset_universe.csv             # 30 S&P 500 constituents across 11 GICS sectors
│       ├── sp500_daily_prices_2015_2024.csv   # 10-year daily adjusted close prices (1,994 trading days)
│       ├── sp500_daily_returns_2015_2024.csv  # 10-year daily log returns
│       ├── apel_dct_energy.csv            # Empirical APEL DCT-II energy concentration curves
│       ├── circuit_scaling.csv            # CNOT count and two-qubit depth scaling benchmarks
│       ├── crossover_projection.csv       # Quantum advantage crossover sensitivity projections
│       ├── nahea_pruning_bounds.csv       # Hamiltonian perturbation bounds and spectral gaps
│       ├── qpas_attributions.csv          # Per-asset QPAS attribution decomposition scores
│       ├── regime_performance.csv         # Out-of-sample Bull, Bear, Recovery performance metrics
│       └── statistical_tests.csv          # Diebold-Mariano and Holm-Bonferroni test statistics
│
├── matlab/                                # MATLAB empirical reconstruction & figure generation
│   ├── run_all.m                          # Master runner generating all figures
│   ├── run_full_reconstruction_pipeline.m # End-to-end data processing and model evaluation pipeline
│   ├── verify_consistency.m              # 5-Gate automated scientific integrity audit
│   ├── export_all_figures.m               # Vector graphic export utility (PDF, EPS, PNG)
│   ├── test_pipeline_recalc.m             # Test suite for numerical pipeline recalculations
│   ├── fetch_market_data.ps1              # Automated financial market data downloader
│   ├── fig01_efficient_frontier.m         # Figure 1: Mean-variance frontier with cardinality bounds
│   ├── fig02_qubo_mapping.m               # Figure 2: QUBO Hamiltonian coupling matrix & sparsity
│   ├── fig03_circuit_depth.m              # Figure 3: Two-qubit depth and CNOT count vs asset universe
│   ├── fig04_convergence.m                # Figure 4: Variational parameter convergence trajectories
│   ├── fig05_sharpe_comparison.m          # Figure 5: Out-of-sample Sharpe ratio distributions across regimes
│   ├── fig06_risk_return.m                # Figure 6: Annualized risk vs return scatter across market phases
│   ├── fig07_heatmap_correlation.m        # Figure 7: 30-asset empirical correlation heatmap (11 GICS sectors)
│   ├── fig08_qubit_scaling.m              # Figure 8: Qubit and circuit resource scaling across ansatz topologies
│   ├── fig09_noise_sensitivity.m          # Figure 9: Fidelity degradation under depolarizing and thermal noise
│   └── fig10_portfolio_weights.m          # Figure 10: Dynamic portfolio asset allocation weights over time
│
├── python/                                # Python verification and demonstration scripts
│   ├── adapt_qfo_demo.py                  # Standalone end-to-end demonstration of APEL, NAHEA & QPAS
│   ├── doi_verifier.py                    # CrossRef, Datacite & arXiv DOI automated validator
│   └── requirements.txt                   # Python dependencies (Qiskit, NumPy, SciPy, CVXPY)
│
├── figures/                               # Publication-ready figures and TikZ vector source files
│   ├── fig_01_efficient_frontier.{eps,pdf,png}
│   ├── fig_02_qubo_mapping.{eps,pdf,png}
│   ├── fig_03_circuit_depth.{eps,pdf,png}
│   ├── fig_04_convergence.{eps,pdf,png}
│   ├── fig_05_sharpe_comparison.{eps,pdf,png}
│   ├── fig_06_risk_return.{eps,pdf,png}
│   ├── fig_07_heatmap_correlation.{eps,pdf,png}
│   ├── fig_08_qubit_scaling.{eps,pdf,png}
│   ├── fig_09_noise_sensitivity.{eps,pdf,png}
│   ├── fig_10_portfolio_weights.{eps,pdf,png}
│   ├── fig_S1_dct_spectrum.{tex,pdf,png}
│   ├── fig_S2_kyoto_topology.{tex,pdf,png}
│   ├── fig_S3_hyperparam_surface.{tex,pdf,png}
│   ├── fig_S4_audit_trail_schema.{tex,pdf,png}
│   └── figure_manifest.csv                # Complete figure metadata and caption index
│
├── references.bib                         # 69 verified scholarly citations with validated DOIs
├── all_bib_entries.csv                    # Complete bibliographic database metadata
├── clean_verified_references.csv          # Cross-referenced bibliographic verification index
├── verified_crossref_entries.csv          # CrossRef API verification responses
├── verify_integrity.ps1                   # PowerShell end-to-end integrity test script
├── LICENSE                                # MIT Open Research License
└── README.md                              # This documentation file
```

---

## Getting Started

### Prerequisites

- **MATLAB**: R2022b or newer (with Optimization Toolbox, Statistics and Machine Learning Toolbox).
- **Python**: 3.9 or newer (with `numpy`, `scipy`, `pandas`).

### Quick Start: Python Demonstration

To run a standalone simulation demonstration of APEL encoding, QUBO generation, and QPAS factor attribution:
```bash
cd python
pip install -r requirements.txt
python adapt_qfo_demo.py
```

### Quick Start: Reproducing Figures in MATLAB

1. Open MATLAB and navigate to the `matlab/` directory:
   ```matlab
   cd('path/to/ADAPT-QFO/matlab');
   ```

2. Run the master figure reproduction script:
   ```matlab
   run_all
   ```
   This regenerates all Figures 1 through 10 and saves high-resolution publication-quality vector outputs into `figures/`.

3. Run the automated 5-Gate Scientific Integrity Audit:
   ```matlab
   verify_consistency
   ```
   This verifies:
   - **Gate 1:** Numerical validity and row counts across all core CSV benchmarks.
   - **Gate 2:** QUBO matrix symmetry, exact QUBO-MIQP objective equivalence ($|\Delta| < 10^{-10}$), APEL Frobenius bounds, and NAHEA ground-state preservation.
   - **Gate 3:** Hardware class bifurcation (Class A: $n \le 27$ heavy-hex subgraph; Class B: extended simulator) and circuit depth reductions ($37.4\%$ depth, $48.6\%$ CNOTs).
   - **Gate 4:** Statistical hypothesis testing (Diebold-Mariano $p < 0.001$ vs heuristic baselines; no significant difference vs exact MIQP).
   - **Gate 5:** Cross-asset uniformity, Sharpe ratios, and simulation disclaimers.

---

## Key Empirical Results

Out-of-sample annualized risk-adjusted performance across 50 independent stochastic repetitions:

| Market Regime | Period | Classical MVO | Black-Litterman | HRP | Exact MIQP$^{\dagger}$ | Standard QAOA | **ADAPT-QFO (Ours)** | Improvement vs MVO |
|---|---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **Bull** | 2017–19, 2023–24 | $1.18$ | $1.27$ | $1.28$ | $1.48$ | $1.24 \pm 0.16$ | **$1.47 \pm 0.14$** | **$+24.6\%$** |
| **Bear** | 2020, 2022 | $0.31$ | $0.34$ | $0.38$ | $0.42$ | $0.33 \pm 0.16$ | **$0.41 \pm 0.16$** | **$+32.3\%$** |
| **Recovery** | 2020–21 | $1.32$ | $1.46$ | $1.51$ | $1.76$ | $1.38 \pm 0.18$ | **$1.73 \pm 0.13$** | **$+31.1\%$** |

$^{\dagger}$Exact MIQP reference solved to proven global optimality (MIP Gap $= 0.00\%$) via branch-and-cut. Diebold-Mariano tests confirm that ADAPT-QFO's out-of-sample performance is close to exact MIQP ($p = 0.337$) while rejecting equal expected loss against classical heuristics and unconstrained MVO ($p < 0.001$).

---

## Dataset Description

The research benchmark universe comprises **30 representative S&P 500 constituents** spanning all 11 GICS economic sectors over the 10-year historical window from January 1, 2015 to December 31, 2024 (1,994 trading days):

- **Information Technology:** AAPL, MSFT, NVDA, CSCO
- **Communication Services:** GOOGL, META
- **Financials:** BRK-B, JPM, V
- **Health Care:** UNH, JNJ, LLY
- **Consumer Discretionary:** AMZN, HD, TSLA
- **Consumer Staples:** PG, KO, COST
- **Energy:** XOM, CVX
- **Utilities:** NEE, SO, DUK
- **Industrials:** CAT, UNP, GE
- **Materials:** LIN, SHW
- **Real Estate:** AMT, PLD
- *External Benchmark (strictly isolated):* SPY (SPDR S&P 500 ETF Trust)

---

## Simulation-Based Scope Disclaimer

All quantum simulation benchmarks were performed using **Qiskit Aer** configured with open-system density matrix simulation and a representative heavy-hex noise model (`HH-27-REF-A` / `KYOTO-27-REF-A`) parameterized from published superconducting architecture characteristics. For $n \le 27$, circuits map onto a 27-qubit heavy-hex simulator subgraph (Class A); instances at $n \ge 28$ are evaluated on an extended simulator topology (Class B). All experiments are simulation-based; no physical quantum hardware execution or quantum advantage is claimed.

---

## Citation

If you use this codebase or benchmark dataset in your research, please cite:

```bibtex
@article{AlWardi_2026_ADAPTQFO,
  author    = {Hamood Amur Al Wardi and Uvesh Husain and Shylaja H N and Ram Soorat and Priyanka and Afzalur Rahman},
  title     = {ADAPT-QFO: A Noise-Aware Hybrid Quantum-Classical Framework for Intelligent Portfolio Optimization},
  journal   = {Expert Systems with Applications},
  year      = {2026},
  note      = {Under Review}
}
```

---

## License

This repository is licensed under the [MIT License](LICENSE).  
The financial market dataset is provided for academic reproducibility purposes.
