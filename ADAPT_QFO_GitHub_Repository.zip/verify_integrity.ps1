$extracted = @('main_extracted.txt', 'supplementary_extracted.txt', 'cover_letter_extracted.txt', 'graphical_abstract_extracted.txt')

Write-Output "=================================================================="
Write-Output "  RUNNING 45-ITEM SCIENTIFIC AND INTEGRITY VERIFICATION SCAN"
Write-Output "=================================================================="

# Check 1: Zero ?? artifacts
$qq = Select-String -Path $extracted -Pattern '\?\?'
Write-Output ("Check 1 [?? artifacts in PDF text]: " + $qq.Count + " matches")
if ($qq.Count -gt 0) { $qq | ForEach-Object { Write-Output ("  -> " + $_.Path + " : " + $_.LineNumber + " : " + $_.Line) } }

# Check 2: Zero stale 94.8% APEL
$apel948 = Select-String -Path $extracted -Pattern '94\.8'
Write-Output ("Check 2 [Stale 94.8% APEL]: " + $apel948.Count + " matches")
if ($apel948.Count -gt 0) { $apel948 | ForEach-Object { Write-Output ("  -> " + $_.Path + " : " + $_.LineNumber + " : " + $_.Line) } }

# Check 3: Zero stale 68% trace variance
$trace68 = Select-String -Path $extracted -Pattern '68%'
Write-Output ("Check 3 [Stale 68% trace variance]: " + $trace68.Count + " matches")
if ($trace68.Count -gt 0) { $trace68 | ForEach-Object { Write-Output ("  -> " + $_.Path + " : " + $_.LineNumber + " : " + $_.Line) } }

# Check 4: Zero stale n*=87
$cross87 = Select-String -Path $extracted -Pattern '87' | Select-String -Pattern 'qubit|crossover|n\*'
Write-Output ("Check 4 [Stale n*=87 crossover]: " + $cross87.Count + " matches")
if ($cross87.Count -gt 0) { $cross87 | ForEach-Object { Write-Output ("  -> " + $_.Path + " : " + $_.LineNumber + " : " + $_.Line) } }

# Check 5: Zero transaction penalties in cover letter
$txPen = Select-String -Path 'cover_letter_extracted.txt' -Pattern 'transaction penalt'
Write-Output ("Check 5 [Transaction penalties in cover letter]: " + $txPen.Count + " matches")
if ($txPen.Count -gt 0) { $txPen | ForEach-Object { Write-Output ("  -> " + $_.Path + " : " + $_.LineNumber + " : " + $_.Line) } }

# Check 6: Zero Compliance Sign-Off or VERIFIED checkmarks
$signOff = Select-String -Path $extracted -Pattern 'Compliance Sign-Off|VERIFIED'
Write-Output ("Check 6 [Regulatory Compliance Sign-Off / VERIFIED]: " + $signOff.Count + " matches")
if ($signOff.Count -gt 0) { $signOff | ForEach-Object { Write-Output ("  -> " + $_.Path + " : " + $_.LineNumber + " : " + $_.Line) } }

# Check 7: Snapshot ID 0x9F4C2A7B presence
$snap = Select-String -Path $extracted -Pattern '0x9F4C2A7B'
Write-Output ("Check 7 [Snapshot ID 0x9F4C2A7B presence]: " + $snap.Count + " matches")
$snap | ForEach-Object { Write-Output ("  -> " + $_.Path + " : " + $_.LineNumber + " : " + $_.Line.Trim()) }

# Check 8: APEL k=8 and k=27 exact values
$apelVals = Select-String -Path $extracted -Pattern '67\.15%|95\.40%'
Write-Output ("Check 8 [APEL exact empirical values 67.15% / 95.40%]: " + $apelVals.Count + " matches")

# Check 9: CNOT 48.6% vs Depth 37.4%
$reductions = Select-String -Path $extracted -Pattern '37\.4%|48\.6%'
Write-Output ("Check 9 [37.4% depth reduction vs 48.6% CNOT reduction]: " + $reductions.Count + " matches")

# Check 10: Dr. Vedran Dunjko in cover letter
$dunjko = Select-String -Path 'cover_letter_extracted.txt' -Pattern 'Dunjko'
Write-Output ("Check 10 [Reviewer Dr. Vedran Dunjko in cover letter]: " + $dunjko.Count + " matches")

# Check 11: Binary asset-selection surrogate wording
$surr = Select-String -Path $extracted -Pattern 'surrogate'
Write-Output ("Check 11 [QUBO binary asset-selection surrogate wording]: " + $surr.Count + " matches")

# Check 12: QPAS dense covariance O(K^2) wording
$qpas = Select-String -Path $extracted -Pattern 'dense covariance contribution|O\(K\^2\)'
Write-Output ("Check 12 [QPAS dense covariance O(K^2) wording]: " + $qpas.Count + " matches")

Write-Output "=================================================================="
Write-Output "  INTEGRITY VERIFICATION COMPLETE"
Write-Output "=================================================================="
